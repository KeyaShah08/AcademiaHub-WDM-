# Getting Started with Create React App

Group 12: 

Keya Kalpeshbhai Shah - 1002079489
Sahithi Velaga - 1002033633
Sreeja Reddy Kakularapu - 1002072005
Tejaswini Seeram - 1002069243
Thirumala Gopi Lakshmisetty - 1002170548


Deployed Application on UTA cloud:

https://txs9243.uta.cloud/

Deployed Blog on UTA cloud using Wordpress: 

https://kxs9489.uta.cloud/post/hello-world/


To run the files submitted in Visual Studio code, the following steps need to be followed:

1)	Install Node.js and npm: Ensure that Node.js and npm (Node Package Manager) installed on the machine.
2)	Set up a React Project: Create a React project or navigate to the existing one. If there is no react project, create a React project 
npx create-react-app react-app-name
3)	Open the Project in Visual Studio Code: 
Launch the Visual Studio.
Using “File” menu to open  the React Project folder. (This can also be done by dragging and dropping the Project folder in Visual Studio Code).
4)	Run the React Application: 
Open the terminal with in the Visual Studio.
Navigate to the React project directory.
Start the development server by running : npm start
Pre requisite is installing of RouterDom using this step: npm install react-router-dom
The above command will build and run the React application and will automatically open in the default browser.
5)	Edit and View:
If any changes done in the React code in Visual Studio code the changes can be seen live in the browser.
6) If you wants to operate the blog, we need to click the button of Blog from homepage and it will redirect to the UTA cloud's Blog page that we made.

------------------------------------------------------------------------------------------------------------------------------------------


This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
