<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package divine_blog
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="featured-image">
			<?php divine_blog_post_thumbnail(); ?>
		</div><!-- .featured-image -->
	<?php endif; ?>

	<footer class="entry-footer">
		<?php divine_blog_entry_footer(); ?>
	</footer><!-- .entry-footer -->

	<header class="entry-header">
		<h2 class="entry-title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
	</header><!-- .entry-header -->

	<?php $excerpt = get_the_excerpt();
	if ( !empty($excerpt) ) { ?>
		<div class="entry-content">
			<?php the_excerpt(); ?>
		</div><!-- .entry-content -->
	<?php } ?>

	<?php if ( 'post' === get_post_type() ) : ?>
		<div class="entry-meta">
			<?php
			divine_blog_posted_on();
			?>
		</div><!-- .entry-meta -->
	<?php endif; ?>
</article><!-- #post-<?php the_ID(); ?> -->