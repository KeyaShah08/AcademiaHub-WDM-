import React from 'react';
import AppRoutes from '../src/Routes';
const App = () => {
  return <AppRoutes/>;
};
export default App;