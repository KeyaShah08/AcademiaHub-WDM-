import React from "react";
import infoCSS from "../CSS/admin_coordinator1.module.css";
import penImage from "../FILES/pen.png";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary

const CoordinatorInformation = () => {
  return (
    <div className={infoCSS["info1-body"]}>
      <div className={infoCSS["navbar"]}>
        <span className={infoCSS["navbar-title"]}>
          Program Coordinator's Information
        </span>
        
        <Link to="/admin_coordinatorsinfo">All Program Coordinator's Info</Link>
      </div>
      <br />
      <Link to="#">
        <button className={infoCSS["info1-button"]}>Edit</button>
      </Link>
      <br />
      <table className={infoCSS["pc-info"]}>
        <br />
        <div>
          <img src={penImage} alt="Edit" />
          <p>
            <span className={infoCSS["info1-label"]}>Name:</span> Azura Kalliope
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>User ID:</span> 24680
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>Access:</span>Granted
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>Address:</span>789 Willow
            Lane, Village, State
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>Email:</span>{" "}
            azura.kalliope@example.com
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>Phone:</span> (555)
            987-1234
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>
              College Joining Date:
            </span>{" "}
            August 20, 2020
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>Years of Experience:</span>{" "}
            8
          </p>
          <p>
            <span className={infoCSS["info1-label"]}>Ratings:</span> 8
          </p>
        </div>
      </table>
    </div>
  );
};

export default CoordinatorInformation;
